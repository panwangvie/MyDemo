# FoxCrawler
爬虫的整理

学习示例文件夹下包含不同的控制台程序，不同的控制台程序使用不同的类库，分析归纳不同类库的优缺点。

- YoukuCrawler [使用HtmlAgilityPack 爬取优酷电影名](https://www.jianshu.com/p/98d8734d1a66)

- YoukuCrawlerAsync [HtmlAgilityPack 爬取优酷电影名进阶（所有分类+多线程）](https://www.jianshu.com/p/01fe631482e7) 2018-05-03更新

- YouKuDotnetSpider2 [爬虫框架Clawler 爬取优酷电影名](https://www.jianshu.com/p/fd07787e6b63) 2018-05-14更新

- YouKuDotnetSpider2Async [爬虫框架Clawler 爬取优酷电影名 分页+多线程](https://www.jianshu.com/p/8c9e190f6ec2) 2018-05-14更新

- Fox.ClawerSN [苏宁百万级商品爬取 思路讲解](https://www.jianshu.com/p/45c997980df0) 2018-07-11更新
- JD.Product.Crawler 京东百万级商品爬取 思路讲解 代码已完成，文档未开始写
- JKNotice [定时从列表中爬今日通知信息，打包成windows服务](https://www.jianshu.com/p/b18ee789fded)
