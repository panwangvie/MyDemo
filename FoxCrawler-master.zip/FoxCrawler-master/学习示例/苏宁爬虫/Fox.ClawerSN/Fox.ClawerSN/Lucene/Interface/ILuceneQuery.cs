﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fox.ClawerSN.Lucene.Interface
{
    public interface ILuceneQuery
    {
    }
}
