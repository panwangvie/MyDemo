﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple.SeleniumClawer.Model
{
    public class NewInfo
    {
        public string Title { get; set; }
        public String Url { get; set; }
    }
}
