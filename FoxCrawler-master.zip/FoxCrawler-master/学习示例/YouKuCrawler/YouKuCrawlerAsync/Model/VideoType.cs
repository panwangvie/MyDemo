﻿namespace YouKuCrawlerAsync
{
    /// <summary>
    ///     视频类别
    /// </summary>
    public class VideoType
    {
        /// <summary>
        ///     名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///     编码
        /// </summary>
        public string Code { get; set; }
    }
}