﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JKNoticeget.Model
{
  public  class Notice
    {
        public string Href { get; set; }
        public string Title { get; set; }
        public string Dep { get; set; }
        public string Time { get; set; }
    }
}
